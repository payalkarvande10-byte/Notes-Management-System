import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import API from '../api';

const DEPARTMENTS = ['Computer Science','Information Technology','Electronics','Mechanical','Civil','Electrical','MBA','MCA'];
const SEMESTERS = ['1st','2nd','3rd','4th','5th','6th','7th','8th'];

export default function TeacherDashboard() {
  const [active, setActive] = useState('dashboard');
  const [profile, setProfile] = useState(null);
  const [myClasses, setMyClasses] = useState([]);
  const [allClasses, setAllClasses] = useState([]);
  const [joinedClasses, setJoinedClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [notes, setNotes] = useState([]);
  const [requests, setRequests] = useState([]);
  const [teacherRequests, setTeacherRequests] = useState([]);
  const [classForm, setClassForm] = useState({ class_name:'', department:'', semester:'', description:'' });
  const [subjectForm, setSubjectForm] = useState({ subject_name:'', class_id:'' });
  const [noteForm, setNoteForm] = useState({ title:'', description:'', subject_id:'', class_id:'', file:null });
  const [subjectsByClass, setSubjectsByClass] = useState([]);
  const navigate = useNavigate();
  const name = localStorage.getItem('nms_name') || 'Teacher';

  useEffect(() => {
    if (active === 'profile') fetchProfile();
    if (active === 'my-classes') fetchMyClasses();
    if (active === 'all-classes') fetchAllClasses();
    if (active === 'create-subject') { fetchJoinedClasses(); }
    if (active === 'subjects') fetchSubjects();
    if (active === 'upload-notes') { fetchJoinedClasses(); fetchSubjects(); }
    if (active === 'notes') fetchNotes();
    if (active === 'requests') { fetchRequests(); fetchTeacherRequests(); }
  }, [active]);

  const fetchProfile = async () => {
    try { const r = await API.get('/teacher/profile'); setProfile(r.data); }
    catch(e) { toast.error('Failed to load profile'); }
  };
  const fetchMyClasses = async () => {
    try { const r = await API.get('/teacher/classes'); setMyClasses(r.data); }
    catch(e) { toast.error('Failed to load classes'); }
  };
  const fetchAllClasses = async () => {
    try { const r = await API.get('/teacher/all-classes'); setAllClasses(r.data); }
    catch(e) { toast.error('Failed to load classes'); }
  };
  const fetchJoinedClasses = async () => {
    try { const r = await API.get('/teacher/my-classes'); setJoinedClasses(r.data); }
    catch(e) { toast.error('Failed to load joined classes'); }
  };
  const fetchSubjects = async () => {
    try { const r = await API.get('/teacher/subjects'); setSubjects(r.data); }
    catch(e) { toast.error('Failed to load subjects'); }
  };
  const fetchNotes = async () => {
    try { const r = await API.get('/teacher/notes'); setNotes(r.data); }
    catch(e) { toast.error('Failed to load notes'); }
  };
  const fetchRequests = async () => {
    try { const r = await API.get('/teacher/requests'); setRequests(r.data); }
    catch(e) { toast.error('Failed to load requests'); }
  };
  const fetchTeacherRequests = async () => {
    try { const r = await API.get('/teacher/teacher-requests'); setTeacherRequests(r.data); }
    catch(e) { toast.error('Failed to load teacher requests'); }
  };

  const fetchSubjectsByClass = async (class_id) => {
    if (!class_id) return;
    try { const r = await API.get('/teacher/subjects-by-class/' + class_id); setSubjectsByClass(r.data); }
    catch(e) { setSubjectsByClass([]); }
  };

  const createClass = async (e) => {
    e.preventDefault();
    try {
      await API.post('/teacher/classes', classForm);
      toast.success('Class created!');
      setClassForm({ class_name:'', department:'', semester:'', description:'' });
      setActive('my-classes');
    } catch(e) { toast.error(e.response?.data?.message || 'Failed'); }
  };

  const deleteClass = async (id) => {
    if (!window.confirm('Delete this class?')) return;
    try { await API.delete('/teacher/classes/'+id); toast.success('Class deleted'); fetchMyClasses(); }
    catch(e) { toast.error('Failed to delete'); }
  };

  const sendJoinRequest = async (class_id) => {
    try { await API.post('/teacher/class-join-request', { class_id }); toast.success('Join request sent!'); fetchAllClasses(); }
    catch(e) { toast.error(e.response?.data?.message || 'Failed'); }
  };

  const createSubject = async (e) => {
    e.preventDefault();
    try {
      await API.post('/teacher/subjects', subjectForm);
      toast.success('Subject created!');
      setSubjectForm({ subject_name:'', class_id:'' });
      setActive('subjects');
    } catch(e) { toast.error(e.response?.data?.message || 'Failed'); }
  };

  const deleteSubject = async (id) => {
    if (!window.confirm('Delete this subject?')) return;
    try { await API.delete('/teacher/subjects/'+id); toast.success('Deleted'); fetchSubjects(); }
    catch(e) { toast.error('Failed'); }
  };

  const uploadNote = async (e) => {
    e.preventDefault();
    const fd = new FormData();
    fd.append('title', noteForm.title);
    fd.append('description', noteForm.description);
    fd.append('subject_id', noteForm.subject_id);
    fd.append('class_id', noteForm.class_id);
    if (noteForm.file) fd.append('file', noteForm.file);
    try {
      await API.post('/teacher/notes', fd, { headers:{ 'Content-Type':'multipart/form-data' } });
      toast.success('Notes uploaded!');
      setNoteForm({ title:'', description:'', subject_id:'', class_id:'', file:null });
      setActive('notes');
    } catch(e) { toast.error(e.response?.data?.message || 'Failed'); }
  };

  const deleteNote = async (id) => {
    if (!window.confirm('Delete this note?')) return;
    try { await API.delete('/teacher/notes/'+id); toast.success('Deleted'); fetchNotes(); }
    catch(e) { toast.error('Failed'); }
  };

  const handleStudentRequest = async (id, status) => {
    try { await API.put('/teacher/requests/'+id, { status }); toast.success(`Request ${status}`); fetchRequests(); }
    catch(e) { toast.error('Failed'); }
  };

  const handleTeacherRequest = async (id, status) => {
    try { await API.put('/teacher/teacher-requests/'+id, { status }); toast.success(`Request ${status}`); fetchTeacherRequests(); }
    catch(e) { toast.error('Failed'); }
  };

  const logout = () => { localStorage.clear(); navigate('/login'); };

  const deleteProfile = async () => {
    if (!window.confirm('Delete your account?')) return;
    try { await API.delete('/teacher/profile'); localStorage.clear(); navigate('/login'); }
    catch(e) { toast.error('Failed'); }
  };

  const navItems = [
    { key:'dashboard', label:'Dashboard', icon:'🏠' },
    { key:'create-class', label:'Create Class', icon:'➕' },
    { key:'my-classes', label:'My Classes', icon:'🏫' },
    { key:'all-classes', label:'All Classes', icon:'🌐' },
    { key:'create-subject', label:'Create Subject', icon:'📚' },
    { key:'subjects', label:'View Subjects', icon:'📖' },
    { key:'upload-notes', label:'Upload Notes', icon:'⬆️' },
    { key:'notes', label:'View Notes', icon:'📄' },
    { key:'requests', label:'Requests', icon:'📨' },
    { key:'profile', label:'My Profile', icon:'👤' },
  ];

  return (
    <div style={s.layout}>
      <aside style={s.sidebar}>
        <div style={s.sidebarLogo}>
          <span style={s.logoIcon}>📚</span>
          <div>
            <div style={s.logoText}>NMS</div>
            <div style={s.logoSub}>Teacher Portal</div>
          </div>
        </div>
        <div style={s.userCard}>
          <div style={s.avatar}>{name.charAt(0).toUpperCase()}</div>
          <div>
            <div style={s.userName}>{name}</div>
            <div style={s.userRole}>Teacher</div>
          </div>
        </div>
        <nav style={s.nav}>
          {navItems.map(item => (
            <button key={item.key} style={{ ...s.navBtn, ...(active===item.key ? s.navBtnActive : {}) }}
              onClick={() => setActive(item.key)}>
              <span style={s.navIcon}>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
        <button style={s.logoutBtn} onClick={logout}>🚪 Logout</button>
      </aside>

      <main style={s.main}>
        <div style={s.topbar}>
          <h2 style={s.pageTitle}>
            {active==='dashboard' && '🏠 Teacher Dashboard'}
            {active==='create-class' && '➕ Create Class'}
            {active==='my-classes' && '🏫 My Classes'}
            {active==='all-classes' && '🌐 All Classes'}
            {active==='create-subject' && '📚 Create Subject'}
            {active==='subjects' && '📖 My Subjects'}
            {active==='upload-notes' && '⬆️ Upload Notes'}
            {active==='notes' && '📄 My Notes'}
            {active==='requests' && '📨 Requests'}
            {active==='profile' && '👤 My Profile'}
          </h2>
          <div style={s.topRight}>
            <span style={s.badge}>👨‍🏫 {name}</span>
            <button style={s.homeBtn} onClick={() => navigate('/login')}>🏠 Home</button>
          </div>
        </div>

        <div style={s.content}>

          {/* DASHBOARD */}
          {active === 'dashboard' && (
            <div>
              <div style={s.welcomeBanner}>
                <h2 style={s.welcomeTitle}>Welcome, {name}! 👨‍🏫</h2>
                <p style={s.welcomeSub}>Manage your classes, subjects and notes from here.</p>
              </div>
              <div style={s.cards}>
                {navItems.filter(n=>n.key!=='dashboard').map(c => (
                  <div key={c.key} style={s.dashCard} onClick={() => setActive(c.key)}>
                    <div style={s.dashCardIcon}>{c.icon}</div>
                    <div style={s.dashCardLabel}>{c.label}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CREATE CLASS */}
          {active === 'create-class' && (
            <div style={s.formCard}>
              <h3 style={s.formTitle}>➕ Create New Class</h3>
              <form onSubmit={createClass} style={s.form}>
                <div style={s.field}>
                  <label style={s.label}>Class Name *</label>
                  <input style={s.input} placeholder="e.g. CS 3rd Sem A" value={classForm.class_name}
                    onChange={e => setClassForm({...classForm, class_name:e.target.value})} required />
                </div>
                <div style={s.field}>
                  <label style={s.label}>Department *</label>
                  <select style={s.select} value={classForm.department}
                    onChange={e => setClassForm({...classForm, department:e.target.value})} required>
                    <option value="">-- Select Department --</option>
                    {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div style={s.field}>
                  <label style={s.label}>Semester *</label>
                  <select style={s.select} value={classForm.semester}
                    onChange={e => setClassForm({...classForm, semester:e.target.value})} required>
                    <option value="">-- Select Semester --</option>
                    {SEMESTERS.map(sem => <option key={sem} value={sem}>{sem} Semester</option>)}
                  </select>
                </div>
                <div style={s.field}>
                  <label style={s.label}>Description</label>
                  <textarea style={{...s.input, height:'80px', resize:'vertical'}} placeholder="Class description (optional)"
                    value={classForm.description} onChange={e => setClassForm({...classForm, description:e.target.value})} />
                </div>
                <button style={s.btn} type="submit">Create Class</button>
              </form>
            </div>
          )}

          {/* MY CLASSES */}
          {active === 'my-classes' && (
            <div>
              <h3 style={s.sectionTitle}>🏫 My Created Classes ({myClasses.length})</h3>
              {myClasses.length > 0 ? (
                <div style={s.classGrid}>
                  {myClasses.map(cls => (
                    <div key={cls.class_id} style={s.classCard}>
                      <div style={s.classCardTop}>
                        <div>
                          <div style={s.className}>{cls.class_name}</div>
                          <div style={s.classMeta}>{cls.department} • {cls.semester} Sem</div>
                        </div>
                        <button style={s.delBtn} onClick={() => deleteClass(cls.class_id)}>🗑️</button>
                      </div>
                      <div style={s.classInfo}>
                        <span>👨‍🏫 {cls.teacher_name}</span>
                        <span>📧 {cls.teacher_email}</span>
                      </div>
                      {cls.description && <div style={s.classDesc}>{cls.description}</div>}
                    </div>
                  ))}
                </div>
              ) : <div style={s.empty}>No classes created yet.</div>}
            </div>
          )}

          {/* ALL CLASSES - Join other teachers classes */}
          {active === 'all-classes' && (
            <div>
              <h3 style={s.sectionTitle}>🌐 All Classes — Browse & Join ({allClasses.length})</h3>
              {allClasses.length > 0 ? (
                <div style={s.classGrid}>
                  {allClasses.map(cls => (
                    <div key={cls.class_id} style={s.classCard}>
                      <div style={s.classCardTop}>
                        <div>
                          <div style={s.className}>{cls.class_name}</div>
                          <div style={s.classMeta}>{cls.department} • {cls.semester} Sem</div>
                        </div>
                        {cls.is_owner ? (
                          <span style={s.ownerBadge}>👑 Owner</span>
                        ) : cls.is_joined ? (
                          <span style={s.joinedBadge}>✅ Joined</span>
                        ) : cls.request_sent ? (
                          <span style={s.pendingBadge}>⏳ Pending</span>
                        ) : (
                          <button style={s.joinBtn} onClick={() => sendJoinRequest(cls.class_id)}>
                            ➕ Join
                          </button>
                        )}
                      </div>
                      <div style={s.classInfo}>
                        <span>👨‍🏫 Created by: {cls.teacher_name}</span>
                        <span>📧 {cls.teacher_email}</span>
                      </div>
                      {cls.description && <div style={s.classDesc}>{cls.description}</div>}
                    </div>
                  ))}
                </div>
              ) : <div style={s.empty}>No classes available.</div>}
            </div>
          )}

          {/* CREATE SUBJECT */}
          {active === 'create-subject' && (
            <div style={s.formCard}>
              <h3 style={s.formTitle}>📚 Create New Subject</h3>
              <form onSubmit={createSubject} style={s.form}>
                <div style={s.field}>
                  <label style={s.label}>Subject Name *</label>
                  <input style={s.input} placeholder="e.g. Data Structures" value={subjectForm.subject_name}
                    onChange={e => setSubjectForm({...subjectForm, subject_name:e.target.value})} required />
                </div>
                <div style={s.field}>
                  <label style={s.label}>Select Class *</label>
                  <select style={s.select} value={subjectForm.class_id}
                    onChange={e => setSubjectForm({...subjectForm, class_id:e.target.value})} required>
                    <option value="">-- Select Class --</option>
                    {joinedClasses.map(c => (
                      <option key={c.class_id} value={c.class_id}>
                        {c.class_name} ({c.department} - {c.semester} Sem){c.is_owner ? ' 👑' : ' ✅'}
                      </option>
                    ))}
                  </select>
                </div>
                <button style={s.btn} type="submit">Create Subject</button>
              </form>
            </div>
          )}

          {/* VIEW SUBJECTS */}
          {active === 'subjects' && (
            <div>
              <h3 style={s.sectionTitle}>📖 My Subjects ({subjects.length})</h3>
              {subjects.length > 0 ? (
                <div style={s.tableWrap}>
                  <table style={s.table}>
                    <thead>
                      <tr style={s.thead}>
                        <th style={s.th}>#</th>
                        <th style={s.th}>Subject Name</th>
                        <th style={s.th}>Class</th>
                        <th style={s.th}>Department</th>
                        <th style={s.th}>Semester</th>
                        <th style={s.th}>Teacher</th>
                        <th style={s.th}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {subjects.map((sub, i) => (
                        <tr key={sub.subject_id} style={i%2===0?s.trEven:s.trOdd}>
                          <td style={s.td}>{i+1}</td>
                          <td style={s.td}><strong>{sub.subject_name}</strong></td>
                          <td style={s.td}>{sub.class_name}</td>
                          <td style={s.td}>{sub.department}</td>
                          <td style={s.td}>{sub.semester}</td>
                          <td style={s.td}>{sub.teacher_name}</td>
                          <td style={s.td}>
                            <button style={s.delBtnSm} onClick={() => deleteSubject(sub.subject_id)}>🗑️ Delete</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : <div style={s.empty}>No subjects created yet.</div>}
            </div>
          )}

          {/* UPLOAD NOTES */}
          {active === 'upload-notes' && (
            <div style={s.formCard}>
              <h3 style={s.formTitle}>⬆️ Upload Notes</h3>
              <form onSubmit={uploadNote} style={s.form}>
                <div style={s.field}>
                  <label style={s.label}>Notes Title *</label>
                  <input style={s.input} placeholder="e.g. Unit 1 - Introduction" value={noteForm.title}
                    onChange={e => setNoteForm({...noteForm, title:e.target.value})} required />
                </div>
                <div style={s.field}>
                  <label style={s.label}>Description</label>
                  <textarea style={{...s.input, height:'70px', resize:'vertical'}} placeholder="Optional description"
                    value={noteForm.description} onChange={e => setNoteForm({...noteForm, description:e.target.value})} />
                </div>
                <div style={s.field}>
                  <label style={s.label}>Select Class *</label>
                  <select style={s.select} value={noteForm.class_id}
                    onChange={e => { setNoteForm({...noteForm, class_id:e.target.value, subject_id:''}); fetchSubjectsByClass(e.target.value); }} required>
                    <option value="">-- Select Class --</option>
                    {joinedClasses.map(c => (
                      <option key={c.class_id} value={c.class_id}>
                        {c.class_name} ({c.department}){c.is_owner ? ' 👑' : ' ✅'}
                      </option>
                    ))}
                  </select>
                </div>
                <div style={s.field}>
                  <label style={s.label}>Select Subject *</label>
                  <select style={s.select} value={noteForm.subject_id}
                    onChange={e => setNoteForm({...noteForm, subject_id:e.target.value})} required>
                    <option value="">-- Select Subject --</option>
                    {subjectsByClass.map(sub => (
                      <option key={sub.subject_id} value={sub.subject_id}>{sub.subject_name}</option>
                    ))}
                  </select>
                </div>
                <div style={s.field}>
                  <label style={s.label}>Upload File (PDF/DOC/PPT)</label>
                  <input style={s.input} type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.txt"
                    onChange={e => setNoteForm({...noteForm, file:e.target.files[0]})} />
                </div>
                <button style={s.btn} type="submit">Upload Notes</button>
              </form>
            </div>
          )}

          {/* VIEW NOTES */}
          {active === 'notes' && (
            <div>
              <h3 style={s.sectionTitle}>📄 My Uploaded Notes ({notes.length})</h3>
              {notes.length > 0 ? (
                <div style={s.tableWrap}>
                  <table style={s.table}>
                    <thead>
                      <tr style={s.thead}>
                        <th style={s.th}>#</th>
                        <th style={s.th}>Title</th>
                        <th style={s.th}>Subject</th>
                        <th style={s.th}>Class</th>
                        <th style={s.th}>Department</th>
                        <th style={s.th}>Semester</th>
                        <th style={s.th}>Date</th>
                        <th style={s.th}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {notes.map((note, i) => (
                        <tr key={note.note_id} style={i%2===0?s.trEven:s.trOdd}>
                          <td style={s.td}>{i+1}</td>
                          <td style={s.td}><strong>{note.title}</strong></td>
                          <td style={s.td}>{note.subject_name}</td>
                          <td style={s.td}>{note.class_name}</td>
                          <td style={s.td}>{note.department}</td>
                          <td style={s.td}>{note.semester}</td>
                          <td style={s.td}>{new Date(note.upload_date).toLocaleDateString()}</td>
                          <td style={s.td}>
                            {note.file_path && <a href={'/uploads/'+note.file_path} target="_blank" rel="noreferrer" style={s.viewLink}>📥</a>}
                            <button style={s.delBtnSm} onClick={() => deleteNote(note.note_id)}>🗑️</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : <div style={s.empty}>No notes uploaded yet.</div>}
            </div>
          )}

          {/* REQUESTS */}
          {active === 'requests' && (
            <div>
              {/* Student Requests */}
              <h3 style={s.sectionTitle}>🎓 Student Join Requests ({requests.length})</h3>
              {requests.length > 0 ? (
                <div style={{...s.tableWrap, marginBottom:'32px'}}>
                  <table style={s.table}>
                    <thead>
                      <tr style={s.thead}>
                        <th style={s.th}>#</th>
                        <th style={s.th}>Student</th>
                        <th style={s.th}>Email</th>
                        <th style={s.th}>Roll No</th>
                        <th style={s.th}>Dept</th>
                        <th style={s.th}>Sem</th>
                        <th style={s.th}>Class</th>
                        <th style={s.th}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {requests.map((req, i) => (
                        <tr key={req.request_id} style={i%2===0?s.trEven:s.trOdd}>
                          <td style={s.td}>{i+1}</td>
                          <td style={s.td}>{req.student_name}</td>
                          <td style={s.td}>{req.student_email}</td>
                          <td style={s.td}>{req.roll_no||'-'}</td>
                          <td style={s.td}>{req.department}</td>
                          <td style={s.td}>{req.semester}</td>
                          <td style={s.td}>{req.class_name}</td>
                          <td style={s.td}>
                            <button style={s.approveBtn} onClick={() => handleStudentRequest(req.request_id,'approved')}>✅</button>
                            <button style={s.rejectBtn} onClick={() => handleStudentRequest(req.request_id,'rejected')}>❌</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : <div style={{...s.empty, marginBottom:'24px'}}>No pending student requests.</div>}

              {/* Teacher Requests */}
              <h3 style={s.sectionTitle}>👨‍🏫 Teacher Join Requests ({teacherRequests.length})</h3>
              {teacherRequests.length > 0 ? (
                <div style={s.tableWrap}>
                  <table style={s.table}>
                    <thead>
                      <tr style={s.thead}>
                        <th style={s.th}>#</th>
                        <th style={s.th}>Teacher Name</th>
                        <th style={s.th}>Email</th>
                        <th style={s.th}>Department</th>
                        <th style={s.th}>Class</th>
                        <th style={s.th}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {teacherRequests.map((req, i) => (
                        <tr key={req.id} style={i%2===0?s.trEven:s.trOdd}>
                          <td style={s.td}>{i+1}</td>
                          <td style={s.td}>{req.teacher_name}</td>
                          <td style={s.td}>{req.teacher_email}</td>
                          <td style={s.td}>{req.department}</td>
                          <td style={s.td}>{req.class_name}</td>
                          <td style={s.td}>
                            <button style={s.approveBtn} onClick={() => handleTeacherRequest(req.id,'approved')}>✅ Approve</button>
                            <button style={s.rejectBtn} onClick={() => handleTeacherRequest(req.id,'rejected')}>❌ Reject</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : <div style={s.empty}>No pending teacher requests.</div>}
            </div>
          )}

          {/* PROFILE */}
          {active === 'profile' && profile && (
            <div style={s.profileCard}>
              <div style={s.profileHeader}>
                <div style={s.profileAvatar}>{profile.name?.charAt(0).toUpperCase()}</div>
                <div>
                  <h2 style={s.profileName}>{profile.name}</h2>
                  <p style={s.profileRole}>👨‍🏫 Teacher</p>
                </div>
              </div>
              <div style={s.profileGrid}>
                {[
                  { label:'Full Name', value:profile.name, icon:'👤' },
                  { label:'Department', value:profile.department, icon:'🏢' },
                  { label:'Email', value:profile.email, icon:'📧' },
                  { label:'Registered On', value:new Date(profile.created_at).toLocaleDateString(), icon:'📆' },
                ].map(item => (
                  <div key={item.label} style={s.profileItem}>
                    <span style={s.profileItemIcon}>{item.icon}</span>
                    <div>
                      <div style={s.profileLabel}>{item.label}</div>
                      <div style={s.profileValue}>{item.value}</div>
                    </div>
                  </div>
                ))}
              </div>
              <button style={s.deleteBtn} onClick={deleteProfile}>🗑️ Delete Account</button>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}

const s = {
  layout: { display:'flex', minHeight:'100vh', fontFamily:'Poppins,sans-serif', background:'#f0f4f8' },
  sidebar: { width:'240px', background:'#1e3a5f', display:'flex', flexDirection:'column', padding:'20px 14px', position:'sticky', top:0, height:'100vh', overflowY:'auto' },
  sidebarLogo: { display:'flex', alignItems:'center', gap:'10px', marginBottom:'20px', padding:'0 6px' },
  logoIcon: { fontSize:'28px' },
  logoText: { color:'#fff', fontWeight:'800', fontSize:'18px' },
  logoSub: { color:'rgba(255,255,255,0.4)', fontSize:'11px' },
  userCard: { display:'flex', alignItems:'center', gap:'10px', background:'rgba(255,255,255,0.08)', borderRadius:'10px', padding:'12px', marginBottom:'18px' },
  avatar: { width:'38px', height:'38px', borderRadius:'50%', background:'#3b82f6', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:'700', fontSize:'16px', flexShrink:0 },
  userName: { color:'#fff', fontWeight:'600', fontSize:'13px' },
  userRole: { color:'rgba(255,255,255,0.4)', fontSize:'11px' },
  nav: { display:'flex', flexDirection:'column', gap:'3px', flex:1 },
  navBtn: { display:'flex', alignItems:'center', gap:'8px', padding:'10px 10px', borderRadius:'8px', border:'none', background:'transparent', color:'rgba(255,255,255,0.6)', fontSize:'13px', cursor:'pointer', fontFamily:'Poppins,sans-serif', textAlign:'left' },
  navBtnActive: { background:'rgba(59,130,246,0.2)', color:'#fff', borderLeft:'3px solid #3b82f6' },
  navIcon: { fontSize:'15px', width:'20px' },
  logoutBtn: { padding:'10px 12px', borderRadius:'8px', border:'1px solid rgba(239,68,68,0.4)', background:'rgba(239,68,68,0.1)', color:'#fca5a5', fontSize:'13px', cursor:'pointer', fontFamily:'Poppins,sans-serif', marginTop:'10px' },
  main: { flex:1, display:'flex', flexDirection:'column', overflow:'auto' },
  topbar: { background:'#fff', padding:'14px 24px', display:'flex', justifyContent:'space-between', alignItems:'center', boxShadow:'0 2px 8px rgba(0,0,0,0.06)', position:'sticky', top:0, zIndex:100 },
  pageTitle: { fontSize:'18px', fontWeight:'700', color:'#1e3a5f' },
  topRight: { display:'flex', gap:'10px', alignItems:'center' },
  badge: { background:'#eff6ff', padding:'6px 12px', borderRadius:'20px', fontSize:'12px', color:'#1d4ed8', fontWeight:'500' },
  homeBtn: { padding:'7px 14px', borderRadius:'7px', border:'1px solid #3b82f6', background:'transparent', color:'#3b82f6', cursor:'pointer', fontSize:'12px', fontFamily:'Poppins,sans-serif' },
  content: { padding:'24px', flex:1 },
  welcomeBanner: { background:'linear-gradient(135deg,#1e3a5f,#1d4ed8)', borderRadius:'14px', padding:'28px', marginBottom:'24px', color:'#fff' },
  welcomeTitle: { fontSize:'22px', fontWeight:'700', marginBottom:'6px' },
  welcomeSub: { color:'rgba(255,255,255,0.7)', fontSize:'13px' },
  cards: { display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(140px,1fr))', gap:'14px' },
  dashCard: { background:'#fff', borderRadius:'12px', padding:'20px 14px', cursor:'pointer', boxShadow:'0 4px 12px rgba(0,0,0,0.06)', textAlign:'center', border:'1px solid #e8edf2' },
  dashCardIcon: { fontSize:'28px', marginBottom:'8px' },
  dashCardLabel: { fontWeight:'600', fontSize:'12px', color:'#1e3a5f' },
  formCard: { background:'#fff', borderRadius:'14px', padding:'28px', maxWidth:'520px', boxShadow:'0 4px 16px rgba(0,0,0,0.08)' },
  formTitle: { fontSize:'18px', fontWeight:'700', color:'#1e3a5f', marginBottom:'20px' },
  form: { display:'flex', flexDirection:'column', gap:'14px' },
  field: { display:'flex', flexDirection:'column', gap:'5px' },
  label: { fontSize:'13px', fontWeight:'600', color:'#374151' },
  input: { padding:'11px 13px', borderRadius:'8px', border:'1.5px solid #d1d5db', fontSize:'13px', fontFamily:'Poppins,sans-serif', outline:'none', background:'#f9fafb', color:'#111827' },
  select: { padding:'11px 13px', borderRadius:'8px', border:'1.5px solid #d1d5db', fontSize:'13px', fontFamily:'Poppins,sans-serif', outline:'none', background:'#f9fafb', color:'#111827', cursor:'pointer' },
  btn: { padding:'12px', borderRadius:'8px', background:'#1e3a5f', border:'none', color:'#fff', fontSize:'14px', fontWeight:'600', cursor:'pointer', fontFamily:'Poppins,sans-serif' },
  sectionTitle: { fontSize:'17px', fontWeight:'700', color:'#1e3a5f', marginBottom:'16px' },
  classGrid: { display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))', gap:'16px' },
  classCard: { background:'#fff', borderRadius:'14px', padding:'18px', boxShadow:'0 4px 12px rgba(0,0,0,0.06)', border:'1px solid #e8edf2' },
  classCardTop: { display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:'10px' },
  className: { fontWeight:'700', fontSize:'14px', color:'#1e3a5f' },
  classMeta: { fontSize:'12px', color:'#6b7280', marginTop:'2px' },
  classInfo: { display:'flex', flexDirection:'column', gap:'3px', fontSize:'12px', color:'#4b5563' },
  classDesc: { fontSize:'12px', color:'#9ca3af', fontStyle:'italic', marginTop:'6px' },
  delBtn: { background:'none', border:'none', cursor:'pointer', fontSize:'16px' },
  joinBtn: { padding:'5px 12px', borderRadius:'6px', background:'#1e3a5f', border:'none', color:'#fff', fontSize:'12px', cursor:'pointer', fontFamily:'Poppins,sans-serif', fontWeight:'600' },
  ownerBadge: { fontSize:'12px', background:'#fef3c7', color:'#92400e', padding:'4px 8px', borderRadius:'6px', fontWeight:'600' },
  joinedBadge: { fontSize:'12px', background:'#dcfce7', color:'#166534', padding:'4px 8px', borderRadius:'6px', fontWeight:'600' },
  pendingBadge: { fontSize:'12px', background:'#fef9c3', color:'#854d0e', padding:'4px 8px', borderRadius:'6px', fontWeight:'600' },
  tableWrap: { background:'#fff', borderRadius:'14px', overflow:'auto', boxShadow:'0 4px 12px rgba(0,0,0,0.06)' },
  table: { width:'100%', borderCollapse:'collapse', minWidth:'600px' },
  thead: { background:'#1e3a5f' },
  th: { padding:'12px 14px', color:'#fff', fontSize:'12px', fontWeight:'600', textAlign:'left', whiteSpace:'nowrap' },
  trEven: { background:'#fff' },
  trOdd: { background:'#f8fafc' },
  td: { padding:'11px 14px', fontSize:'12px', color:'#374151', borderBottom:'1px solid #f0f4f8', whiteSpace:'nowrap' },
  delBtnSm: { padding:'4px 8px', borderRadius:'5px', background:'#fee2e2', border:'none', color:'#dc2626', cursor:'pointer', fontSize:'11px', fontFamily:'Poppins,sans-serif', marginLeft:'4px' },
  viewLink: { marginRight:'6px', fontSize:'14px' },
  approveBtn: { padding:'4px 8px', borderRadius:'5px', background:'#dcfce7', border:'none', color:'#16a34a', cursor:'pointer', fontSize:'11px', fontFamily:'Poppins,sans-serif', marginRight:'4px' },
  rejectBtn: { padding:'4px 8px', borderRadius:'5px', background:'#fee2e2', border:'none', color:'#dc2626', cursor:'pointer', fontSize:'11px', fontFamily:'Poppins,sans-serif' },
  profileCard: { background:'#fff', borderRadius:'16px', padding:'32px', boxShadow:'0 4px 16px rgba(0,0,0,0.08)', maxWidth:'560px' },
  profileHeader: { display:'flex', gap:'16px', alignItems:'center', marginBottom:'24px', paddingBottom:'18px', borderBottom:'2px solid #f0f4f8' },
  profileAvatar: { width:'60px', height:'60px', borderRadius:'50%', background:'#1e3a5f', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:'800', fontSize:'24px', flexShrink:0 },
  profileName: { fontSize:'22px', fontWeight:'700', color:'#1e3a5f' },
  profileRole: { fontSize:'13px', color:'#6b7280', marginTop:'3px' },
  profileGrid: { display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:'12px', marginBottom:'20px' },
  profileItem: { display:'flex', gap:'12px', alignItems:'flex-start', padding:'12px', background:'#f8fafc', borderRadius:'10px', border:'1px solid #e8edf2' },
  profileItemIcon: { fontSize:'18px', flexShrink:0 },
  profileLabel: { fontSize:'11px', color:'#9ca3af', fontWeight:'500', marginBottom:'2px' },
  profileValue: { fontSize:'13px', color:'#1e3a5f', fontWeight:'600' },
  deleteBtn: { padding:'10px 20px', borderRadius:'8px', background:'#dc2626', border:'none', color:'#fff', fontSize:'13px', cursor:'pointer', fontFamily:'Poppins,sans-serif', fontWeight:'600' },
  empty: { textAlign:'center', padding:'50px', color:'#9ca3af', fontSize:'14px', background:'#fff', borderRadius:'14px' }
};
