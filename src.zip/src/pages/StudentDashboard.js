import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import API from '../api';

const DEPARTMENTS = ['Computer Science','Information Technology','Electronics','Mechanical','Civil','Electrical','MBA','MCA'];
const SEMESTERS = ['1st','2nd','3rd','4th','5th','6th','7th','8th'];

export default function StudentDashboard() {
  const [active, setActive] = useState('dashboard');
  const [profile, setProfile] = useState(null);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [notes, setNotes] = useState([]);
  const [filterDept, setFilterDept] = useState('');
  const [filterSem, setFilterSem] = useState('');
  const [selectedSubject, setSelectedSubject] = useState(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const navigate = useNavigate();
  const name = localStorage.getItem('nms_name') || 'Student';

  useEffect(() => { if (active === 'profile') fetchProfile(); }, [active]);
  useEffect(() => { if (active === 'subjects') fetchSubjects(); }, [active]);

  const fetchProfile = async () => {
    try { const res = await API.get('/student/profile'); setProfile(res.data); }
    catch (e) { toast.error('Failed to load profile'); }
  };

  const fetchClasses = async () => {
    if (!filterDept || !filterSem) { toast.warning('Please select department and semester'); return; }
    try { const res = await API.get(`/student/classes?department=${filterDept}&semester=${filterSem}`); setClasses(res.data); }
    catch (e) { toast.error('Failed to load classes'); }
  };

  const fetchSubjects = async () => {
    try { const res = await API.get('/student/subjects'); setSubjects(res.data); }
    catch (e) { toast.error(e.response?.data?.message || 'Not joined any class yet'); setSubjects([]); }
  };

  const fetchNotes = async (subject_id, subject_name) => {
    try {
      const res = await API.get('/student/notes/' + subject_id);
      setNotes(res.data); setSelectedSubject(subject_name); setActive('notes');
    } catch (e) { toast.error('Failed to load notes'); }
  };

  const joinClass = async (class_id) => {
    try { await API.post('/student/join-request', { class_id }); toast.success('Join request sent!'); }
    catch (e) { toast.error(e.response?.data?.message || 'Failed to send request'); }
  };

  const logout = () => {
    localStorage.clear();
    navigate('/login');
  };

  const deleteProfile = async () => {
    if (!window.confirm('Delete your account permanently?')) return;
    try { await API.delete('/student/profile'); localStorage.clear(); navigate('/login'); }
    catch (e) { toast.error('Failed to delete profile'); }
  };

  const navItems = [
    { key:'dashboard', label:'Dashboard', icon:'🏠' },
    { key:'classes', label:'View Classes', icon:'🏫' },
    { key:'subjects', label:'View Subjects', icon:'📖' },
    { key:'profile', label:'My Profile', icon:'👤' },
  ];

  return (
    <div style={s.layout}>
      {/* Sidebar */}
      <aside style={s.sidebar}>
        <div style={s.sidebarLogo}>
          <span style={s.logoIcon}>📚</span>
          <div>
            <div style={s.logoText}>NMS</div>
            <div style={s.logoSub}>Student Portal</div>
          </div>
        </div>
        <div style={s.userCard}>
          <div style={s.avatar}>{name.charAt(0).toUpperCase()}</div>
          <div>
            <div style={s.userName}>{name}</div>
            <div style={s.userRole}>Student</div>
          </div>
        </div>
        <nav style={s.nav}>
          {navItems.map(item => (
            <button key={item.key} style={{ ...s.navBtn, ...(active===item.key ? s.navBtnActive : {}) }}
              onClick={() => setActive(item.key)}>
              <span style={s.navIcon}>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
        <button style={s.logoutBtn} onClick={logout}>🚪 Logout</button>
      </aside>

      {/* Main content */}
      <main style={s.main}>
        {/* Top bar */}
        <div style={s.topbar}>
          <h2 style={s.pageTitle}>
            {active === 'dashboard' && '🏠 Student Dashboard'}
            {active === 'classes' && '🏫 View Classes'}
            {active === 'subjects' && '📖 View Subjects'}
            {active === 'notes' && `📄 Notes - ${selectedSubject}`}
            {active === 'profile' && '👤 My Profile'}
          </h2>
          <div style={s.topRight}>
            <span style={s.badge}>🎓 {name}</span>
            <button style={s.homeBtn} onClick={() => navigate('/login')}>🏠 Home</button>
          </div>
        </div>

        <div style={s.content}>

          {/* DASHBOARD */}
          {active === 'dashboard' && (
            <div>
              <div style={s.welcomeBanner}>
                <h2 style={s.welcomeTitle}>Welcome back, {name}! 👋</h2>
                <p style={s.welcomeSub}>Manage your classes, subjects and notes from here.</p>
              </div>
              <div style={s.cards}>
                {[
                  { icon:'🏫', label:'View Classes', desc:'Browse & join classes by department and semester', key:'classes' },
                  { icon:'📖', label:'View Subjects', desc:'View subjects of your joined class', key:'subjects' },
                  { icon:'👤', label:'My Profile', desc:'View and manage your profile', key:'profile' },
                ].map(c => (
                  <div key={c.key} style={s.dashCard} onClick={() => setActive(c.key)}>
                    <div style={s.dashCardIcon}>{c.icon}</div>
                    <div style={s.dashCardLabel}>{c.label}</div>
                    <div style={s.dashCardDesc}>{c.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* VIEW CLASSES */}
          {active === 'classes' && (
            <div>
              <div style={s.filterBox}>
                <h3 style={s.sectionTitle}>🔍 Filter Classes</h3>
                <div style={s.filterRow}>
                  <select style={s.select} value={filterDept} onChange={e => setFilterDept(e.target.value)}>
                    <option value="">Select Department</option>
                    {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                  <select style={s.select} value={filterSem} onChange={e => setFilterSem(e.target.value)}>
                    <option value="">Select Semester</option>
                    {SEMESTERS.map(sem => <option key={sem} value={sem}>{sem} Semester</option>)}
                  </select>
                  <button style={s.searchBtn} onClick={fetchClasses}>Search Classes</button>
                </div>
              </div>
              {classes.length > 0 ? (
                <div style={s.classGrid}>
                  {classes.map(cls => (
                    <div key={cls.class_id} style={s.classCard}>
                      <div style={s.classCardHead}>
                        <span style={s.classIcon}>🏫</span>
                        <div>
                          <div style={s.className}>{cls.class_name}</div>
                          <div style={s.classMeta}>{cls.department} • {cls.semester} Sem</div>
                        </div>
                      </div>
                      <div style={s.classTeacher}>👨‍🏫 {cls.teacher_name}</div>
                      {cls.description && <div style={s.classDesc}>{cls.description}</div>}
                      <button style={s.joinBtn} onClick={() => joinClass(cls.class_id)}>
                        ✉️ Send Join Request
                      </button>
                    </div>
                  ))}
                </div>
              ) : <div style={s.empty}>Select department and semester to see available classes</div>}
            </div>
          )}

          {/* VIEW SUBJECTS */}
          {active === 'subjects' && (
            <div>
              <h3 style={s.sectionTitle}>📖 Subjects in Your Class</h3>
              {subjects.length > 0 ? (
                <div style={s.classGrid}>
                  {subjects.map(sub => (
                    <div key={sub.subject_id} style={s.subjectCard}>
                      <div style={s.subjectIcon}>📗</div>
                      <div style={s.subjectName}>{sub.subject_name}</div>
                      <div style={s.subjectMeta}>
                        <span>🏫 {sub.class_name}</span>
                        <span>👨‍🏫 {sub.teacher_name}</span>
                        <span>📅 {sub.semester} • {sub.department}</span>
                      </div>
                      <button style={s.notesBtn} onClick={() => fetchNotes(sub.subject_id, sub.subject_name)}>
                        📄 View Notes
                      </button>
                    </div>
                  ))}
                </div>
              ) : <div style={s.empty}>You haven't joined any class yet. Go to "View Classes" to join one.</div>}
            </div>
          )}

          {/* NOTES */}
          {active === 'notes' && (
            <div>
              <button style={s.backBtn} onClick={() => setActive('subjects')}>← Back to Subjects</button>
              <h3 style={s.sectionTitle}>📄 Notes for {selectedSubject}</h3>
              {notes.length > 0 ? (
                <div style={s.notesGrid}>
                  {notes.map(note => (
                    <div key={note.note_id} style={s.noteCard}>
                      <div style={s.noteTitle}>{note.title}</div>
                      {note.description && <div style={s.noteDesc}>{note.description}</div>}
                      <div style={s.noteMeta}>
                        <span>👨‍🏫 {note.teacher_name}</span>
                        <span>📅 {new Date(note.upload_date).toLocaleDateString()}</span>
                      </div>
                      {note.file_path && (
                        <a href={`/uploads/${note.file_path}`} target="_blank" rel="noreferrer" style={s.downloadBtn}>
                          ⬇️ Download Notes
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              ) : <div style={s.empty}>No notes uploaded for this subject yet.</div>}
            </div>
          )}

          {/* PROFILE */}
          {active === 'profile' && profile && (
            <div style={s.profileCard}>
              <div style={s.profileHeader}>
                <div style={s.profileAvatar}>{profile.name?.charAt(0).toUpperCase()}</div>
                <div>
                  <h2 style={s.profileName}>{profile.name}</h2>
                  <p style={s.profileRole}>🎓 Student</p>
                </div>
              </div>
              <div style={s.profileGrid}>
                {[
                  { label:'Roll Number', value: profile.roll_no || 'N/A', icon:'🔢' },
                  { label:'Full Name', value: profile.name, icon:'👤' },
                  { label:'Department', value: profile.department, icon:'🏢' },
                  { label:'Semester', value: profile.semester, icon:'📅' },
                  { label:'Contact', value: profile.contact || 'N/A', icon:'📞' },
                  { label:'Email', value: profile.email, icon:'📧' },
                  { label:'Registered On', value: new Date(profile.created_at).toLocaleDateString(), icon:'📆' },
                ].map(item => (
                  <div key={item.label} style={s.profileItem}>
                    <span style={s.profileItemIcon}>{item.icon}</span>
                    <div>
                      <div style={s.profileLabel}>{item.label}</div>
                      <div style={s.profileValue}>{item.value}</div>
                    </div>
                  </div>
                ))}
              </div>
              <button style={s.deleteBtn} onClick={deleteProfile}>🗑️ Delete Account</button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

const s = {
  layout: { display:'flex', minHeight:'100vh', fontFamily:'Poppins,sans-serif', background:'#f0f4f8' },
  sidebar: { width:'260px', background:'linear-gradient(180deg,#1a1a2e 0%,#16213e 100%)', display:'flex', flexDirection:'column', padding:'24px 16px', position:'sticky', top:0, height:'100vh', overflowY:'auto' },
  sidebarLogo: { display:'flex', alignItems:'center', gap:'12px', marginBottom:'28px', padding:'0 8px' },
  logoIcon: { fontSize:'32px' },
  logoText: { color:'#fff', fontWeight:'800', fontSize:'20px', letterSpacing:'-0.5px' },
  logoSub: { color:'rgba(255,255,255,0.4)', fontSize:'11px' },
  userCard: { display:'flex', alignItems:'center', gap:'12px', background:'rgba(255,255,255,0.07)', borderRadius:'12px', padding:'14px', marginBottom:'24px' },
  avatar: { width:'42px', height:'42px', borderRadius:'50%', background:'linear-gradient(135deg,#e94560,#c62a47)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:'700', fontSize:'18px', flexShrink:0 },
  userName: { color:'#fff', fontWeight:'600', fontSize:'14px' },
  userRole: { color:'rgba(255,255,255,0.4)', fontSize:'12px' },
  nav: { display:'flex', flexDirection:'column', gap:'6px', flex:1 },
  navBtn: { display:'flex', alignItems:'center', gap:'10px', padding:'12px 14px', borderRadius:'10px', border:'none', background:'transparent', color:'rgba(255,255,255,0.6)', fontSize:'14px', cursor:'pointer', fontFamily:'Poppins,sans-serif', textAlign:'left', transition:'all 0.2s' },
  navBtnActive: { background:'linear-gradient(135deg,rgba(233,69,96,0.3),rgba(15,52,96,0.3))', color:'#fff', borderLeft:'3px solid #e94560' },
  navIcon: { fontSize:'18px', width:'24px' },
  logoutBtn: { padding:'12px 14px', borderRadius:'10px', border:'1px solid rgba(233,69,96,0.4)', background:'rgba(233,69,96,0.1)', color:'#e94560', fontSize:'14px', cursor:'pointer', fontFamily:'Poppins,sans-serif', marginTop:'16px' },
  main: { flex:1, display:'flex', flexDirection:'column' },
  topbar: { background:'#fff', padding:'16px 28px', display:'flex', justifyContent:'space-between', alignItems:'center', boxShadow:'0 2px 8px rgba(0,0,0,0.06)', position:'sticky', top:0, zIndex:100 },
  pageTitle: { fontSize:'20px', fontWeight:'700', color:'#1a1a2e' },
  topRight: { display:'flex', gap:'12px', alignItems:'center' },
  badge: { background:'#f0f4f8', padding:'8px 14px', borderRadius:'20px', fontSize:'13px', color:'#1a1a2e', fontWeight:'500' },
  homeBtn: { padding:'8px 16px', borderRadius:'8px', border:'1px solid #e94560', background:'transparent', color:'#e94560', cursor:'pointer', fontSize:'13px', fontFamily:'Poppins,sans-serif' },
  content: { padding:'28px', flex:1 },
  welcomeBanner: { background:'linear-gradient(135deg,#1a1a2e,#0f3460)', borderRadius:'16px', padding:'32px', marginBottom:'28px', color:'#fff' },
  welcomeTitle: { fontSize:'24px', fontWeight:'700', marginBottom:'8px' },
  welcomeSub: { color:'rgba(255,255,255,0.6)', fontSize:'14px' },
  cards: { display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:'20px' },
  dashCard: { background:'#fff', borderRadius:'16px', padding:'28px 24px', cursor:'pointer', boxShadow:'0 4px 15px rgba(0,0,0,0.06)', transition:'all 0.2s', border:'1px solid #e8edf2', textAlign:'center' },
  dashCardIcon: { fontSize:'36px', marginBottom:'12px' },
  dashCardLabel: { fontWeight:'700', fontSize:'16px', color:'#1a1a2e', marginBottom:'6px' },
  dashCardDesc: { fontSize:'13px', color:'#6b7280' },
  filterBox: { background:'#fff', borderRadius:'16px', padding:'24px', marginBottom:'24px', boxShadow:'0 4px 15px rgba(0,0,0,0.06)' },
  sectionTitle: { fontSize:'18px', fontWeight:'700', color:'#1a1a2e', marginBottom:'16px' },
  filterRow: { display:'flex', gap:'12px', flexWrap:'wrap', alignItems:'center' },
  select: { padding:'11px 14px', borderRadius:'10px', border:'1px solid #e2e8f0', fontSize:'14px', fontFamily:'Poppins,sans-serif', outline:'none', minWidth:'180px', background:'#f8fafc' },
  searchBtn: { padding:'11px 22px', borderRadius:'10px', background:'linear-gradient(135deg,#e94560,#c62a47)', border:'none', color:'#fff', fontSize:'14px', cursor:'pointer', fontFamily:'Poppins,sans-serif', fontWeight:'600' },
  classGrid: { display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:'20px' },
  classCard: { background:'#fff', borderRadius:'16px', padding:'22px', boxShadow:'0 4px 15px rgba(0,0,0,0.06)', border:'1px solid #e8edf2' },
  classCardHead: { display:'flex', gap:'12px', alignItems:'flex-start', marginBottom:'12px' },
  classIcon: { fontSize:'28px', flexShrink:0 },
  className: { fontWeight:'700', fontSize:'15px', color:'#1a1a2e' },
  classMeta: { fontSize:'12px', color:'#6b7280', marginTop:'2px' },
  classTeacher: { fontSize:'13px', color:'#4b5563', marginBottom:'8px' },
  classDesc: { fontSize:'12px', color:'#9ca3af', marginBottom:'12px', fontStyle:'italic' },
  joinBtn: { width:'100%', padding:'10px', borderRadius:'10px', background:'linear-gradient(135deg,#e94560,#c62a47)', border:'none', color:'#fff', fontSize:'13px', cursor:'pointer', fontFamily:'Poppins,sans-serif', fontWeight:'600' },
  subjectCard: { background:'#fff', borderRadius:'16px', padding:'22px', boxShadow:'0 4px 15px rgba(0,0,0,0.06)', border:'1px solid #e8edf2', textAlign:'center' },
  subjectIcon: { fontSize:'36px', marginBottom:'10px' },
  subjectName: { fontWeight:'700', fontSize:'16px', color:'#1a1a2e', marginBottom:'10px' },
  subjectMeta: { display:'flex', flexDirection:'column', gap:'4px', fontSize:'12px', color:'#6b7280', marginBottom:'14px' },
  notesBtn: { padding:'10px 20px', borderRadius:'10px', background:'linear-gradient(135deg,#0f3460,#16213e)', border:'none', color:'#fff', fontSize:'13px', cursor:'pointer', fontFamily:'Poppins,sans-serif', fontWeight:'600' },
  notesGrid: { display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:'20px' },
  noteCard: { background:'#fff', borderRadius:'16px', padding:'22px', boxShadow:'0 4px 15px rgba(0,0,0,0.06)', border:'1px solid #e8edf2' },
  noteTitle: { fontWeight:'700', fontSize:'15px', color:'#1a1a2e', marginBottom:'8px' },
  noteDesc: { fontSize:'13px', color:'#6b7280', marginBottom:'12px' },
  noteMeta: { display:'flex', gap:'12px', fontSize:'12px', color:'#9ca3af', marginBottom:'14px', flexWrap:'wrap' },
  downloadBtn: { display:'inline-block', padding:'10px 18px', borderRadius:'10px', background:'linear-gradient(135deg,#059669,#047857)', color:'#fff', fontSize:'13px', textDecoration:'none', fontWeight:'600' },
  backBtn: { padding:'8px 18px', borderRadius:'8px', border:'1px solid #e2e8f0', background:'transparent', color:'#6b7280', fontSize:'13px', cursor:'pointer', marginBottom:'16px', fontFamily:'Poppins,sans-serif' },
  profileCard: { background:'#fff', borderRadius:'20px', padding:'36px', boxShadow:'0 4px 20px rgba(0,0,0,0.08)', maxWidth:'700px' },
  profileHeader: { display:'flex', gap:'20px', alignItems:'center', marginBottom:'32px', paddingBottom:'24px', borderBottom:'2px solid #f0f4f8' },
  profileAvatar: { width:'70px', height:'70px', borderRadius:'50%', background:'linear-gradient(135deg,#e94560,#c62a47)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:'800', fontSize:'28px', flexShrink:0 },
  profileName: { fontSize:'24px', fontWeight:'700', color:'#1a1a2e' },
  profileRole: { fontSize:'14px', color:'#6b7280', marginTop:'4px' },
  profileGrid: { display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:'16px', marginBottom:'28px' },
  profileItem: { display:'flex', gap:'14px', alignItems:'flex-start', padding:'16px', background:'#f8fafc', borderRadius:'12px', border:'1px solid #e8edf2' },
  profileItemIcon: { fontSize:'22px', flexShrink:0 },
  profileLabel: { fontSize:'12px', color:'#9ca3af', fontWeight:'500', marginBottom:'2px' },
  profileValue: { fontSize:'15px', color:'#1a1a2e', fontWeight:'600' },
  deleteBtn: { padding:'12px 24px', borderRadius:'10px', background:'linear-gradient(135deg,#dc2626,#b91c1c)', border:'none', color:'#fff', fontSize:'14px', cursor:'pointer', fontFamily:'Poppins,sans-serif', fontWeight:'600' },
  empty: { textAlign:'center', padding:'60px 20px', color:'#9ca3af', fontSize:'15px', background:'#fff', borderRadius:'16px' }
};
