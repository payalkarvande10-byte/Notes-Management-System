import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import API from '../api';

export default function AdminDashboard() {
  const [active, setActive] = useState('dashboard');
  const [profile, setProfile] = useState(null);
  const [departments, setDepartments] = useState([]);
  const [selDept, setSelDept] = useState('');
  const [teachers, setTeachers] = useState([]);
  const [students, setStudents] = useState([]);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [notes, setNotes] = useState([]);
  const [deptSelected, setDeptSelected] = useState(false);
  const navigate = useNavigate();
  const name = localStorage.getItem('nms_name') || 'Admin';

  const DEPARTMENTS = ['Computer Science','Information Technology','Electronics','Mechanical','Civil','Electrical','MBA','MCA'];

  useEffect(() => {
    if (active === 'profile') fetchProfile();
    setSelDept(''); setDeptSelected(false);
    setTeachers([]); setStudents([]); setClasses([]); setSubjects([]); setNotes([]);
  }, [active]);

  const fetchProfile = async () => {
    try { const r = await API.get('/admin/profile'); setProfile(r.data); }
    catch(e) { toast.error('Failed to load profile'); }
  };

  const fetchTeachers = async (dept) => {
    try { const r = await API.get('/admin/teachers?department='+dept); setTeachers(r.data); setDeptSelected(true); }
    catch(e) { toast.error('Failed to load teachers'); }
  };

  const fetchStudents = async (dept) => {
    try { const r = await API.get('/admin/students?department='+dept); setStudents(r.data); setDeptSelected(true); }
    catch(e) { toast.error('Failed to load students'); }
  };

  const fetchClasses = async (dept) => {
    try { const r = await API.get('/admin/classes?department='+dept); setClasses(r.data); setDeptSelected(true); }
    catch(e) { toast.error('Failed to load classes'); }
  };

  const fetchSubjects = async (dept) => {
    try { const r = await API.get('/admin/subjects?department='+dept); setSubjects(r.data); setDeptSelected(true); }
    catch(e) { toast.error('Failed to load subjects'); }
  };

  const fetchNotes = async (dept) => {
    try { const r = await API.get('/admin/notes?department='+dept); setNotes(r.data); setDeptSelected(true); }
    catch(e) { toast.error('Failed to load notes'); }
  };

  const handleDeptSelect = (dept) => {
    setSelDept(dept);
    if (!dept) return;
    if (active === 'teachers') fetchTeachers(dept);
    if (active === 'students') fetchStudents(dept);
    if (active === 'classes') fetchClasses(dept);
    if (active === 'subjects') fetchSubjects(dept);
    if (active === 'notes') fetchNotes(dept);
  };

  const deleteTeacher = async (id) => {
    if (!window.confirm('Delete this teacher?')) return;
    try { await API.delete('/admin/teachers/'+id); toast.success('Teacher deleted'); fetchTeachers(selDept); }
    catch(e) { toast.error('Failed to delete'); }
  };

  const deleteStudent = async (id) => {
    if (!window.confirm('Delete this student?')) return;
    try { await API.delete('/admin/students/'+id); toast.success('Student deleted'); fetchStudents(selDept); }
    catch(e) { toast.error('Failed to delete'); }
  };

  const logout = () => { localStorage.clear(); navigate('/login'); };

  const navItems = [
    { key:'dashboard', label:'Dashboard', icon:'🏠' },
    { key:'teachers', label:'Teachers', icon:'👨‍🏫' },
    { key:'students', label:'Students', icon:'🎓' },
    { key:'classes', label:'Classes', icon:'🏫' },
    { key:'subjects', label:'Subjects', icon:'📖' },
    { key:'notes', label:'Notes', icon:'📄' },
    { key:'profile', label:'Admin Profile', icon:'⚙️' },
  ];

  const DeptSelector = ({ onSelect }) => (
    <div style={s.deptBox}>
      <h3 style={s.deptTitle}>🏢 Select Department</h3>
      <div style={s.deptGrid}>
        {DEPARTMENTS.map(d => (
          <button key={d} style={{ ...s.deptBtn, ...(selDept===d ? s.deptBtnActive : {}) }}
            onClick={() => { setSelDept(d); onSelect(d); }}>
            {d}
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div style={s.layout}>
      <aside style={s.sidebar}>
        <div style={s.sidebarLogo}>
          <span style={s.logoIcon}>📚</span>
          <div>
            <div style={s.logoText}>NMS</div>
            <div style={s.logoSub}>Admin Panel</div>
          </div>
        </div>
        <div style={s.userCard}>
          <div style={s.avatar}>{name.charAt(0).toUpperCase()}</div>
          <div>
            <div style={s.userName}>{name}</div>
            <div style={s.userRole}>Administrator</div>
          </div>
        </div>
        <nav style={s.nav}>
          {navItems.map(item => (
            <button key={item.key} style={{ ...s.navBtn, ...(active===item.key ? s.navBtnActive : {}) }}
              onClick={() => setActive(item.key)}>
              <span style={s.navIcon}>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
        <button style={s.logoutBtn} onClick={logout}>🚪 Logout</button>
      </aside>

      <main style={s.main}>
        <div style={s.topbar}>
          <h2 style={s.pageTitle}>
            {active==='dashboard' && '🏠 Admin Dashboard'}
            {active==='teachers' && '👨‍🏫 Manage Teachers'}
            {active==='students' && '🎓 Manage Students'}
            {active==='classes' && '🏫 View Classes'}
            {active==='subjects' && '📖 View Subjects'}
            {active==='notes' && '📄 View Notes'}
            {active==='profile' && '⚙️ Admin Profile'}
          </h2>
          <div style={s.topRight}>
            <span style={s.badge}>⚙️ {name}</span>
            <button style={s.homeBtn} onClick={() => navigate('/login')}>🏠 Home</button>
          </div>
        </div>

        <div style={s.content}>

          {/* DASHBOARD */}
          {active === 'dashboard' && (
            <div>
              <div style={s.welcomeBanner}>
                <h2 style={s.welcomeTitle}>Welcome, {name}! ⚙️</h2>
                <p style={s.welcomeSub}>Manage all teachers, students, classes, subjects and notes from here.</p>
              </div>
              <div style={s.cards}>
                {navItems.filter(n=>n.key!=='dashboard').map(c => (
                  <div key={c.key} style={s.dashCard} onClick={() => setActive(c.key)}>
                    <div style={s.dashCardIcon}>{c.icon}</div>
                    <div style={s.dashCardLabel}>{c.label}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TEACHERS */}
          {active === 'teachers' && (
            <div>
              <DeptSelector onSelect={fetchTeachers} />
              {deptSelected && (
                <div>
                  <h3 style={s.sectionTitle}>👨‍🏫 Teachers - {selDept} ({teachers.length})</h3>
                  {teachers.length > 0 ? (
                    <div style={s.tableWrap}>
                      <table style={s.table}>
                        <thead>
                          <tr style={s.thead}>
                            <th style={s.th}>Sr No</th>
                            <th style={s.th}>Name</th>
                            <th style={s.th}>Department</th>
                            <th style={s.th}>Email</th>
                            <th style={s.th}>Registered On</th>
                            <th style={s.th}>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {teachers.map((t, i) => (
                            <tr key={t.teacher_id} style={i%2===0?s.trEven:s.trOdd}>
                              <td style={s.td}>{i+1}</td>
                              <td style={s.td}><strong>{t.name}</strong></td>
                              <td style={s.td}>{t.department}</td>
                              <td style={s.td}>{t.email}</td>
                              <td style={s.td}>{new Date(t.created_at).toLocaleDateString()}</td>
                              <td style={s.td}>
                                <button style={s.delBtnSm} onClick={() => deleteTeacher(t.teacher_id)}>🗑️ Delete</button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : <div style={s.empty}>No teachers found for {selDept} department.</div>}
                </div>
              )}
            </div>
          )}

          {/* STUDENTS */}
          {active === 'students' && (
            <div>
              <DeptSelector onSelect={fetchStudents} />
              {deptSelected && (
                <div>
                  <h3 style={s.sectionTitle}>🎓 Students - {selDept} ({students.length})</h3>
                  {students.length > 0 ? (
                    <div style={s.tableWrap}>
                      <table style={s.table}>
                        <thead>
                          <tr style={s.thead}>
                            <th style={s.th}>Sr No</th>
                            <th style={s.th}>Roll No</th>
                            <th style={s.th}>Name</th>
                            <th style={s.th}>Department</th>
                            <th style={s.th}>Semester</th>
                            <th style={s.th}>Contact</th>
                            <th style={s.th}>Email</th>
                            <th style={s.th}>Registered On</th>
                            <th style={s.th}>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {students.map((st, i) => (
                            <tr key={st.student_id} style={i%2===0?s.trEven:s.trOdd}>
                              <td style={s.td}>{i+1}</td>
                              <td style={s.td}>{st.roll_no || '-'}</td>
                              <td style={s.td}><strong>{st.name}</strong></td>
                              <td style={s.td}>{st.department}</td>
                              <td style={s.td}>{st.semester}</td>
                              <td style={s.td}>{st.contact || '-'}</td>
                              <td style={s.td}>{st.email}</td>
                              <td style={s.td}>{new Date(st.created_at).toLocaleDateString()}</td>
                              <td style={s.td}>
                                <button style={s.delBtnSm} onClick={() => deleteStudent(st.student_id)}>🗑️ Delete</button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : <div style={s.empty}>No students found for {selDept} department.</div>}
                </div>
              )}
            </div>
          )}

          {/* CLASSES */}
          {active === 'classes' && (
            <div>
              <DeptSelector onSelect={fetchClasses} />
              {deptSelected && (
                <div>
                  <h3 style={s.sectionTitle}>🏫 Classes - {selDept} ({classes.length})</h3>
                  {classes.length > 0 ? (
                    <div style={s.tableWrap}>
                      <table style={s.table}>
                        <thead>
                          <tr style={s.thead}>
                            <th style={s.th}>Sr No</th>
                            <th style={s.th}>Class Name</th>
                            <th style={s.th}>Department</th>
                            <th style={s.th}>Semester</th>
                            <th style={s.th}>Teacher Name</th>
                            <th style={s.th}>Teacher Email</th>
                            <th style={s.th}>Created On</th>
                          </tr>
                        </thead>
                        <tbody>
                          {classes.map((cls, i) => (
                            <tr key={cls.class_id} style={i%2===0?s.trEven:s.trOdd}>
                              <td style={s.td}>{i+1}</td>
                              <td style={s.td}><strong>{cls.class_name}</strong></td>
                              <td style={s.td}>{cls.department}</td>
                              <td style={s.td}>{cls.semester}</td>
                              <td style={s.td}>{cls.teacher_name}</td>
                              <td style={s.td}>{cls.teacher_email}</td>
                              <td style={s.td}>{new Date(cls.created_at).toLocaleDateString()}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : <div style={s.empty}>No classes found for {selDept} department.</div>}
                </div>
              )}
            </div>
          )}

          {/* SUBJECTS */}
          {active === 'subjects' && (
            <div>
              <DeptSelector onSelect={fetchSubjects} />
              {deptSelected && (
                <div>
                  <h3 style={s.sectionTitle}>📖 Subjects - {selDept} ({subjects.length})</h3>
                  {subjects.length > 0 ? (
                    <div style={s.tableWrap}>
                      <table style={s.table}>
                        <thead>
                          <tr style={s.thead}>
                            <th style={s.th}>Sr No</th>
                            <th style={s.th}>Subject Name</th>
                            <th style={s.th}>Teacher Name</th>
                            <th style={s.th}>Class</th>
                            <th style={s.th}>Department</th>
                            <th style={s.th}>Semester</th>
                          </tr>
                        </thead>
                        <tbody>
                          {subjects.map((sub, i) => (
                            <tr key={sub.subject_id} style={i%2===0?s.trEven:s.trOdd}>
                              <td style={s.td}>{i+1}</td>
                              <td style={s.td}><strong>{sub.subject_name}</strong></td>
                              <td style={s.td}>{sub.teacher_name}</td>
                              <td style={s.td}>{sub.class_name}</td>
                              <td style={s.td}>{sub.department}</td>
                              <td style={s.td}>{sub.semester}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : <div style={s.empty}>No subjects found for {selDept} department.</div>}
                </div>
              )}
            </div>
          )}

          {/* NOTES */}
          {active === 'notes' && (
            <div>
              <DeptSelector onSelect={fetchNotes} />
              {deptSelected && (
                <div>
                  <h3 style={s.sectionTitle}>📄 Notes - {selDept} ({notes.length})</h3>
                  {notes.length > 0 ? (
                    <div style={s.tableWrap}>
                      <table style={s.table}>
                        <thead>
                          <tr style={s.thead}>
                            <th style={s.th}>Sr No</th>
                            <th style={s.th}>Title</th>
                            <th style={s.th}>Subject</th>
                            <th style={s.th}>Teacher</th>
                            <th style={s.th}>Department</th>
                            <th style={s.th}>Semester</th>
                            <th style={s.th}>Upload Date</th>
                            <th style={s.th}>File</th>
                          </tr>
                        </thead>
                        <tbody>
                          {notes.map((note, i) => (
                            <tr key={note.note_id} style={i%2===0?s.trEven:s.trOdd}>
                              <td style={s.td}>{i+1}</td>
                              <td style={s.td}><strong>{note.title}</strong></td>
                              <td style={s.td}>{note.subject_name}</td>
                              <td style={s.td}>{note.teacher_name}</td>
                              <td style={s.td}>{note.department}</td>
                              <td style={s.td}>{note.semester}</td>
                              <td style={s.td}>{new Date(note.upload_date).toLocaleDateString()}</td>
                              <td style={s.td}>
                                {note.file_path
                                  ? <a href={'/uploads/'+note.file_path} target="_blank" rel="noreferrer" style={s.viewLink}>📥 View</a>
                                  : '-'}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : <div style={s.empty}>No notes found for {selDept} department.</div>}
                </div>
              )}
            </div>
          )}

          {/* PROFILE */}
          {active === 'profile' && profile && (
            <div style={s.profileCard}>
              <div style={s.profileHeader}>
                <div style={s.profileAvatar}>{profile.name?.charAt(0).toUpperCase()}</div>
                <div>
                  <h2 style={s.profileName}>{profile.name}</h2>
                  <p style={s.profileRole}>⚙️ Administrator</p>
                </div>
              </div>
              <div style={s.profileGrid}>
                {[
                  { label:'Full Name', value:profile.name, icon:'👤' },
                  { label:'Email', value:profile.email, icon:'📧' },
                  { label:'Registered On', value:new Date(profile.created_at).toLocaleDateString(), icon:'📆' },
                ].map(item => (
                  <div key={item.label} style={s.profileItem}>
                    <span style={s.profileItemIcon}>{item.icon}</span>
                    <div>
                      <div style={s.profileLabel}>{item.label}</div>
                      <div style={s.profileValue}>{item.value}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}

const s = {
  layout: { display:'flex', minHeight:'100vh', fontFamily:'Poppins,sans-serif', background:'#f0f4f8' },
  sidebar: { width:'260px', background:'linear-gradient(180deg,#1a1a2e 0%,#0f3460 100%)', display:'flex', flexDirection:'column', padding:'24px 16px', position:'sticky', top:0, height:'100vh', overflowY:'auto' },
  sidebarLogo: { display:'flex', alignItems:'center', gap:'12px', marginBottom:'24px', padding:'0 8px' },
  logoIcon: { fontSize:'32px' },
  logoText: { color:'#fff', fontWeight:'800', fontSize:'20px' },
  logoSub: { color:'rgba(255,255,255,0.4)', fontSize:'11px' },
  userCard: { display:'flex', alignItems:'center', gap:'12px', background:'rgba(255,255,255,0.07)', borderRadius:'12px', padding:'14px', marginBottom:'20px' },
  avatar: { width:'42px', height:'42px', borderRadius:'50%', background:'linear-gradient(135deg,#f59e0b,#d97706)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:'700', fontSize:'18px', flexShrink:0 },
  userName: { color:'#fff', fontWeight:'600', fontSize:'14px' },
  userRole: { color:'rgba(255,255,255,0.4)', fontSize:'12px' },
  nav: { display:'flex', flexDirection:'column', gap:'4px', flex:1 },
  navBtn: { display:'flex', alignItems:'center', gap:'10px', padding:'11px 12px', borderRadius:'10px', border:'none', background:'transparent', color:'rgba(255,255,255,0.6)', fontSize:'13px', cursor:'pointer', fontFamily:'Poppins,sans-serif', textAlign:'left' },
  navBtnActive: { background:'rgba(245,158,11,0.2)', color:'#fff', borderLeft:'3px solid #f59e0b' },
  navIcon: { fontSize:'16px', width:'22px' },
  logoutBtn: { padding:'12px 14px', borderRadius:'10px', border:'1px solid rgba(245,158,11,0.4)', background:'rgba(245,158,11,0.1)', color:'#fcd34d', fontSize:'13px', cursor:'pointer', fontFamily:'Poppins,sans-serif', marginTop:'12px' },
  main: { flex:1, display:'flex', flexDirection:'column', overflow:'auto' },
  topbar: { background:'#fff', padding:'16px 28px', display:'flex', justifyContent:'space-between', alignItems:'center', boxShadow:'0 2px 8px rgba(0,0,0,0.06)', position:'sticky', top:0, zIndex:100 },
  pageTitle: { fontSize:'20px', fontWeight:'700', color:'#1a1a2e' },
  topRight: { display:'flex', gap:'12px', alignItems:'center' },
  badge: { background:'#fffbeb', padding:'8px 14px', borderRadius:'20px', fontSize:'13px', color:'#d97706', fontWeight:'500' },
  homeBtn: { padding:'8px 16px', borderRadius:'8px', border:'1px solid #f59e0b', background:'transparent', color:'#d97706', cursor:'pointer', fontSize:'13px', fontFamily:'Poppins,sans-serif' },
  content: { padding:'28px', flex:1 },
  welcomeBanner: { background:'linear-gradient(135deg,#1a1a2e,#0f3460)', borderRadius:'16px', padding:'32px', marginBottom:'28px', color:'#fff' },
  welcomeTitle: { fontSize:'24px', fontWeight:'700', marginBottom:'8px' },
  welcomeSub: { color:'rgba(255,255,255,0.6)', fontSize:'14px' },
  cards: { display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(160px,1fr))', gap:'16px' },
  dashCard: { background:'#fff', borderRadius:'14px', padding:'24px 16px', cursor:'pointer', boxShadow:'0 4px 15px rgba(0,0,0,0.06)', textAlign:'center', border:'1px solid #e8edf2' },
  dashCardIcon: { fontSize:'30px', marginBottom:'10px' },
  dashCardLabel: { fontWeight:'600', fontSize:'13px', color:'#1a1a2e' },
  deptBox: { background:'#fff', borderRadius:'16px', padding:'24px', marginBottom:'24px', boxShadow:'0 4px 15px rgba(0,0,0,0.06)' },
  deptTitle: { fontSize:'16px', fontWeight:'700', color:'#1a1a2e', marginBottom:'16px' },
  deptGrid: { display:'flex', flexWrap:'wrap', gap:'10px' },
  deptBtn: { padding:'10px 18px', borderRadius:'10px', border:'1px solid #e2e8f0', background:'#f8fafc', color:'#374151', fontSize:'13px', cursor:'pointer', fontFamily:'Poppins,sans-serif', fontWeight:'500' },
  deptBtnActive: { background:'linear-gradient(135deg,#f59e0b,#d97706)', border:'1px solid #f59e0b', color:'#fff' },
  sectionTitle: { fontSize:'18px', fontWeight:'700', color:'#1a1a2e', marginBottom:'16px' },
  tableWrap: { background:'#fff', borderRadius:'16px', overflow:'auto', boxShadow:'0 4px 15px rgba(0,0,0,0.06)' },
  table: { width:'100%', borderCollapse:'collapse', minWidth:'700px' },
  thead: { background:'linear-gradient(135deg,#1a1a2e,#0f3460)' },
  th: { padding:'14px 16px', color:'#fff', fontSize:'13px', fontWeight:'600', textAlign:'left', whiteSpace:'nowrap' },
  trEven: { background:'#fff' },
  trOdd: { background:'#f8fafc' },
  td: { padding:'12px 16px', fontSize:'13px', color:'#374151', borderBottom:'1px solid #f0f4f8', whiteSpace:'nowrap' },
  delBtnSm: { padding:'5px 10px', borderRadius:'6px', background:'#fee2e2', border:'none', color:'#dc2626', cursor:'pointer', fontSize:'12px', fontFamily:'Poppins,sans-serif' },
  viewLink: { color:'#3b82f6', textDecoration:'none', fontWeight:'600', fontSize:'13px' },
  profileCard: { background:'#fff', borderRadius:'20px', padding:'36px', boxShadow:'0 4px 20px rgba(0,0,0,0.08)', maxWidth:'600px' },
  profileHeader: { display:'flex', gap:'20px', alignItems:'center', marginBottom:'28px', paddingBottom:'20px', borderBottom:'2px solid #f0f4f8' },
  profileAvatar: { width:'70px', height:'70px', borderRadius:'50%', background:'linear-gradient(135deg,#f59e0b,#d97706)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:'800', fontSize:'28px', flexShrink:0 },
  profileName: { fontSize:'24px', fontWeight:'700', color:'#1a1a2e' },
  profileRole: { fontSize:'14px', color:'#6b7280', marginTop:'4px' },
  profileGrid: { display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))', gap:'14px' },
  profileItem: { display:'flex', gap:'14px', alignItems:'flex-start', padding:'14px', background:'#f8fafc', borderRadius:'12px', border:'1px solid #e8edf2' },
  profileItemIcon: { fontSize:'20px', flexShrink:0 },
  profileLabel: { fontSize:'12px', color:'#9ca3af', fontWeight:'500', marginBottom:'2px' },
  profileValue: { fontSize:'14px', color:'#1a1a2e', fontWeight:'600' },
  empty: { textAlign:'center', padding:'60px', color:'#9ca3af', fontSize:'15px', background:'#fff', borderRadius:'16px' }
};
