import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import API from '../api';

const DEPARTMENTS = ['Computer Science','Information Technology','Electronics','Mechanical','Civil','Electrical','MBA','MCA'];
const SEMESTERS = ['1st','2nd','3rd','4th','5th','6th','7th','8th'];

export default function Register() {
  const [role, setRole] = useState('student');
  const [form, setForm] = useState({ name:'',email:'',password:'',department:'',semester:'',contact:'',roll_no:'' });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await API.post('/auth/register/' + role, form);
      toast.success('Registration successful! Please login.');
      navigate('/login');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const roles = [
    { key:'student', label:'Student', icon:'🎓', color:'#1d4ed8' },
    { key:'teacher', label:'Teacher', icon:'👨‍🏫', color:'#15803d' },
    { key:'admin',   label:'Admin',   icon:'⚙️',  color:'#b45309' },
  ];

  return (
    <div style={S.bg}>
      <div style={S.card}>

        {/* Header */}
        <div style={S.header}>
          <div style={S.logoRow}>
            <span style={S.logoIcon}>📚</span>
            <div>
              <div style={S.logoTitle}>NMS Portal</div>
              <div style={S.logoSub}>Notes Management System</div>
            </div>
          </div>
          <div style={S.divider} />
          <h2 style={S.pageTitle}>New Registration</h2>
          <p style={S.pageSubtitle}>Select your role and fill in your details</p>
        </div>

        {/* Role Tabs */}
        <div style={S.roleTabs}>
          {roles.map(r => (
            <button key={r.key} type="button"
              onClick={() => setRole(r.key)}
              style={{
                ...S.roleTab,
                ...(role === r.key ? { ...S.roleTabActive, borderColor: r.color, color: r.color, background: r.color+'12' } : {})
              }}>
              <span style={S.roleTabIcon}>{r.icon}</span>
              <span style={S.roleTabLabel}>{r.label}</span>
            </button>
          ))}
        </div>

        {/* Form */}
        <form onSubmit={submit} style={S.form}>

          {/* Name */}
          <div style={S.field}>
            <label style={S.label}>Full Name <span style={S.req}>*</span></label>
            <input style={S.input} name="name" placeholder="Enter your full name"
              value={form.name} onChange={handle} required />
          </div>

          {/* Email */}
          <div style={S.field}>
            <label style={S.label}>Email Address <span style={S.req}>*</span></label>
            <input style={S.input} name="email" type="email" placeholder="Enter your email address"
              value={form.email} onChange={handle} required />
          </div>

          {/* Password */}
          <div style={S.field}>
            <label style={S.label}>Password <span style={S.req}>*</span></label>
            <input style={S.input} name="password" type="password" placeholder="Create a strong password"
              value={form.password} onChange={handle} required />
          </div>

          {/* Department - not for admin */}
          {role !== 'admin' && (
            <div style={S.field}>
              <label style={S.label}>Department <span style={S.req}>*</span></label>
              <select style={S.select} name="department" value={form.department} onChange={handle} required>
                <option value="">-- Select Department --</option>
                {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
          )}

          {/* Student only fields */}
          {role === 'student' && (
            <>
              <div style={S.field}>
                <label style={S.label}>Semester <span style={S.req}>*</span></label>
                <select style={S.select} name="semester" value={form.semester} onChange={handle} required>
                  <option value="">-- Select Semester --</option>
                  {SEMESTERS.map(s => <option key={s} value={s}>{s} Semester</option>)}
                </select>
              </div>
              <div style={S.row}>
                <div style={S.field}>
                  <label style={S.label}>Roll Number</label>
                  <input style={S.input} name="roll_no" placeholder="e.g. CS2021001"
                    value={form.roll_no} onChange={handle} />
                </div>
                <div style={S.field}>
                  <label style={S.label}>Contact No.</label>
                  <input style={S.input} name="contact" placeholder="10-digit mobile no."
                    value={form.contact} onChange={handle} />
                </div>
              </div>
            </>
          )}

          <button style={S.btn} type="submit" disabled={loading}>
            {loading ? 'Please wait...' : `Register as ${role.charAt(0).toUpperCase()+role.slice(1)}`}
          </button>
        </form>

        <p style={S.loginLink}>
          Already registered?{' '}
          <Link to="/login" style={S.loginA}>Sign in to your account</Link>
        </p>
      </div>
    </div>
  );
}

const S = {
  bg: {
    minHeight: '100vh',
    background: '#eef2f7',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '30px 16px',
    fontFamily: "'Poppins', sans-serif",
  },
  card: {
    background: '#ffffff',
    borderRadius: '12px',
    padding: '36px 40px',
    width: '100%',
    maxWidth: '520px',
    boxShadow: '0 4px 24px rgba(0,0,0,0.10)',
    border: '1px solid #dde3ec',
  },
  header: {
    marginBottom: '24px',
  },
  logoRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    marginBottom: '16px',
  },
  logoIcon: {
    fontSize: '36px',
  },
  logoTitle: {
    fontSize: '20px',
    fontWeight: '700',
    color: '#1e3a5f',
    lineHeight: 1.2,
  },
  logoSub: {
    fontSize: '12px',
    color: '#6b7280',
  },
  divider: {
    height: '1px',
    background: '#e5e7eb',
    marginBottom: '16px',
  },
  pageTitle: {
    fontSize: '22px',
    fontWeight: '700',
    color: '#111827',
    margin: '0 0 4px 0',
  },
  pageSubtitle: {
    fontSize: '13px',
    color: '#6b7280',
    margin: 0,
  },
  roleTabs: {
    display: 'flex',
    gap: '10px',
    marginBottom: '24px',
  },
  roleTab: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '4px',
    padding: '12px 8px',
    borderRadius: '8px',
    border: '2px solid #e5e7eb',
    background: '#f9fafb',
    color: '#6b7280',
    cursor: 'pointer',
    fontFamily: "'Poppins', sans-serif",
    transition: 'all 0.2s',
  },
  roleTabActive: {
    fontWeight: '600',
  },
  roleTabIcon: {
    fontSize: '22px',
  },
  roleTabLabel: {
    fontSize: '12px',
    fontWeight: '600',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '16px',
  },
  field: {
    display: 'flex',
    flexDirection: 'column',
    gap: '6px',
    flex: 1,
  },
  row: {
    display: 'flex',
    gap: '14px',
  },
  label: {
    fontSize: '13px',
    fontWeight: '600',
    color: '#374151',
  },
  req: {
    color: '#dc2626',
  },
  input: {
    padding: '11px 14px',
    borderRadius: '8px',
    border: '1.5px solid #d1d5db',
    fontSize: '14px',
    color: '#111827',
    fontFamily: "'Poppins', sans-serif",
    outline: 'none',
    background: '#f9fafb',
    width: '100%',
    boxSizing: 'border-box',
  },
  select: {
    padding: '11px 14px',
    borderRadius: '8px',
    border: '1.5px solid #d1d5db',
    fontSize: '14px',
    color: '#111827',
    fontFamily: "'Poppins', sans-serif",
    outline: 'none',
    background: '#f9fafb',
    width: '100%',
    boxSizing: 'border-box',
    cursor: 'pointer',
  },
  btn: {
    marginTop: '8px',
    padding: '13px',
    borderRadius: '8px',
    background: '#1e3a5f',
    border: 'none',
    color: '#ffffff',
    fontSize: '15px',
    fontWeight: '600',
    cursor: 'pointer',
    fontFamily: "'Poppins', sans-serif",
    letterSpacing: '0.3px',
  },
  loginLink: {
    textAlign: 'center',
    marginTop: '20px',
    fontSize: '13px',
    color: '#6b7280',
  },
  loginA: {
    color: '#1d4ed8',
    fontWeight: '600',
    textDecoration: 'none',
  },
};
