import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import API from '../api';

export default function Login() {
  const [form, setForm] = useState({ email:'', password:'', role:'student' });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await API.post('/auth/login', form);
      localStorage.setItem('nms_token', res.data.token);
      localStorage.setItem('nms_role', res.data.role);
      localStorage.setItem('nms_name', res.data.name);
      toast.success('Login successful!');
      navigate('/' + res.data.role);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const roles = [
    { key:'student', label:'Student', icon:'🎓', color:'#1d4ed8' },
    { key:'teacher', label:'Teacher', icon:'👨‍🏫', color:'#15803d' },
    { key:'admin',   label:'Admin',   icon:'⚙️',  color:'#b45309' },
  ];

  return (
    <div style={S.bg}>
      <div style={S.wrapper}>

        {/* Left Info Panel */}
        <div style={S.leftPanel}>
          <div style={S.leftInner}>
            <div style={S.leftLogo}>📚</div>
            <h1 style={S.leftTitle}>Notes Management System</h1>
            <p style={S.leftDesc}>
              A centralized academic platform for managing classes, subjects and notes across departments.
            </p>
            <div style={S.featureList}>
              {[
                '🏫 Class & Subject Management',
                '📄 Notes Upload & Download',
                '👥 Student Join Requests',
                '🔐 Role-Based Secure Access',
              ].map(f => (
                <div key={f} style={S.featureItem}>{f}</div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Login Panel */}
        <div style={S.rightPanel}>
          <div style={S.formBox}>
            <div style={S.formHeader}>
              <h2 style={S.formTitle}>Sign In</h2>
              <p style={S.formSubtitle}>Access your NMS account</p>
            </div>

            {/* Role Selector */}
            <div style={S.roleTabs}>
              {roles.map(r => (
                <button key={r.key} type="button"
                  onClick={() => setForm({ ...form, role: r.key })}
                  style={{
                    ...S.roleTab,
                    ...(form.role === r.key ? {
                      ...S.roleTabActive,
                      borderColor: r.color,
                      color: r.color,
                      background: r.color + '12'
                    } : {})
                  }}>
                  <span style={S.roleTabIcon}>{r.icon}</span>
                  <span style={S.roleTabLabel}>{r.label}</span>
                </button>
              ))}
            </div>

            <form onSubmit={submit} style={S.form}>
              <div style={S.field}>
                <label style={S.label}>Email Address</label>
                <input style={S.input} name="email" type="email"
                  placeholder="Enter your email"
                  value={form.email} onChange={handle} required />
              </div>
              <div style={S.field}>
                <label style={S.label}>Password</label>
                <input style={S.input} name="password" type="password"
                  placeholder="Enter your password"
                  value={form.password} onChange={handle} required />
              </div>
              <button style={S.btn} type="submit" disabled={loading}>
                {loading ? 'Signing in...' : 'Sign In'}
              </button>
            </form>

            <p style={S.registerLink}>
              New user?{' '}
              <Link to="/register" style={S.registerA}>Create an account</Link>
            </p>

            <div style={S.adminHint}>
              <span style={S.adminHintText}>Default Admin: admin@nms.com / admin123</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}

const S = {
  bg: {
    minHeight: '100vh',
    background: '#eef2f7',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '20px',
    fontFamily: "'Poppins', sans-serif",
  },
  wrapper: {
    display: 'flex',
    width: '100%',
    maxWidth: '900px',
    borderRadius: '14px',
    overflow: 'hidden',
    boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
    minHeight: '560px',
  },
  leftPanel: {
    flex: 1,
    background: '#1e3a5f',
    padding: '48px 36px',
    display: 'flex',
    alignItems: 'center',
  },
  leftInner: {
    color: '#fff',
  },
  leftLogo: {
    fontSize: '48px',
    marginBottom: '16px',
  },
  leftTitle: {
    fontSize: '24px',
    fontWeight: '700',
    color: '#fff',
    marginBottom: '14px',
    lineHeight: 1.3,
  },
  leftDesc: {
    fontSize: '13px',
    color: 'rgba(255,255,255,0.7)',
    lineHeight: 1.7,
    marginBottom: '24px',
  },
  featureList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
  },
  featureItem: {
    fontSize: '13px',
    color: 'rgba(255,255,255,0.85)',
    background: 'rgba(255,255,255,0.08)',
    padding: '10px 14px',
    borderRadius: '8px',
    borderLeft: '3px solid #60a5fa',
  },
  rightPanel: {
    width: '420px',
    background: '#ffffff',
    padding: '48px 40px',
    display: 'flex',
    alignItems: 'center',
  },
  formBox: {
    width: '100%',
  },
  formHeader: {
    marginBottom: '24px',
  },
  formTitle: {
    fontSize: '26px',
    fontWeight: '700',
    color: '#111827',
    margin: '0 0 4px 0',
  },
  formSubtitle: {
    fontSize: '13px',
    color: '#6b7280',
    margin: 0,
  },
  roleTabs: {
    display: 'flex',
    gap: '8px',
    marginBottom: '24px',
  },
  roleTab: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '4px',
    padding: '10px 6px',
    borderRadius: '8px',
    border: '2px solid #e5e7eb',
    background: '#f9fafb',
    color: '#6b7280',
    cursor: 'pointer',
    fontFamily: "'Poppins', sans-serif",
  },
  roleTabActive: {
    fontWeight: '600',
  },
  roleTabIcon: { fontSize: '20px' },
  roleTabLabel: { fontSize: '11px', fontWeight: '600' },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '16px',
  },
  field: {
    display: 'flex',
    flexDirection: 'column',
    gap: '6px',
  },
  label: {
    fontSize: '13px',
    fontWeight: '600',
    color: '#374151',
  },
  input: {
    padding: '11px 14px',
    borderRadius: '8px',
    border: '1.5px solid #d1d5db',
    fontSize: '14px',
    color: '#111827',
    fontFamily: "'Poppins', sans-serif",
    outline: 'none',
    background: '#f9fafb',
  },
  btn: {
    marginTop: '4px',
    padding: '13px',
    borderRadius: '8px',
    background: '#1e3a5f',
    border: 'none',
    color: '#ffffff',
    fontSize: '15px',
    fontWeight: '600',
    cursor: 'pointer',
    fontFamily: "'Poppins', sans-serif",
  },
  registerLink: {
    textAlign: 'center',
    marginTop: '18px',
    fontSize: '13px',
    color: '#6b7280',
  },
  registerA: {
    color: '#1d4ed8',
    fontWeight: '600',
    textDecoration: 'none',
  },
  adminHint: {
    marginTop: '16px',
    padding: '10px 14px',
    background: '#fefce8',
    borderRadius: '8px',
    border: '1px solid #fde68a',
    textAlign: 'center',
  },
  adminHintText: {
    fontSize: '12px',
    color: '#92400e',
    fontWeight: '500',
  },
};
